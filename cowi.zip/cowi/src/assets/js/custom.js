
function ExternalJsFile(){
jQuery(function () {

  // counter script
  var a = 0;
$(window).on('scroll',function () {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.counterNumber').each(function () {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function () {
            $this.text(Math.floor(this.countNum));
          },
          complete: function () {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    a = 1;
  }

});

  $(".findnav").on("click", function () {
    $(".navbar-collapse").removeClass('show');
  });

  $(".nav-item").on("click", function () {
    $(".navbar-collapse").removeClass('show');
  });

  $(".dropdown-item").on("click", function () {
    $(".dropdown-menu").removeClass('show');
  });

 


  $(".search-wrapper input").on("keyup",function () {
    $(".search-result").slideDown();
  });


  //  product detail image right align
  var container_left_margin = $('.container').css('marginLeft');
  $('.india-fastest-wrapper').css("margin-left", container_left_margin);


  // dp upload start
  var readURL = function (input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
        $('.profile-pic').attr('src', e.target.result);
      }

      reader.readAsDataURL(input.files[0]);
    }
  }


  $(".file-upload").on("change", function () {
    readURL(this);
  });

  $(".upload-button").on("click", function () {
    $(".file-upload").trigger("click");
  });

  // dp upload end

  // slide menu start
  $(".sideBar-menu").on("click", function () {
    $(".side-bar").toggleClass('active');
  });
  // slide menu end


  // top college filter open start
  $(".advanceFilter").on("click", function () {
    $(".advance-search-wrapper").addClass('active');
    $(".filterOoverlay").css('display', 'block');
  });

  $(".advance-search-wrapper .close").on("click", function () {
    $(".advance-search-wrapper").removeClass('active');
    $(".filterOoverlay").css('display', 'none');
  });

  $(".filterOoverlay").on("click", function () {
    $(".advance-search-wrapper").removeClass('active');
    $(".filterOoverlay").css('display', 'none');
  });


  // accordian  start
  $(".accordian-wrapper .card-header").on("click", function () {
    $(this).parent().toggleClass('active');
    $(this).parent().siblings().removeClass('active');
  });

  // accordian  end


  // filter wrapper started
  $(".filterWrapper .filter .filterIcon").on("click", function () {
    $(".filterWrapper .filter ul").toggleClass('active');
  });
  // filter wrapper end


  // news update page accordian start
  $(".newsUpdatePage-section .searchWrapper").on("click", function () {
    $(this).parent().toggleClass('active');
    $(this).parent().siblings().removeClass('active');
  });
});


}


function notFound(){
  gsap.set("svg", { visibility: "visible" });
  gsap.to("#headStripe", {
    y: 0.5,
    rotation: 1,
    yoyo: true,
    repeat: -1,
    ease: "sine.inOut",
    duration: 1
  });
  gsap.to("#spaceman", {
    y: 0.5,
    rotation: 1,
    yoyo: true,
    repeat: -1,
    ease: "sine.inOut",
    duration: 1
  });
  gsap.to("#craterSmall", {
    x: -3,
    yoyo: true,
    repeat: -1,
    duration: 1,
    ease: "sine.inOut"
  });
  gsap.to("#craterBig", {
    x: 3,
    yoyo: true,
    repeat: -1,
    duration: 1,
    ease: "sine.inOut"
  });
  gsap.to("#planet", {
    rotation: -2,
    yoyo: true,
    repeat: -1,
    duration: 1,
    ease: "sine.inOut",
    transformOrigin: "50% 50%"
  });

  gsap.to("#starsBig g", {
    rotation: "random(-30,30)",
    transformOrigin: "50% 50%",
    yoyo: true,
    repeat: -1,
    ease: "sine.inOut"
  });
  gsap.fromTo(
    "#starsSmall g",
    { scale: 0, transformOrigin: "50% 50%" },
    { scale: 1, transformOrigin: "50% 50%", yoyo: true, repeat: -1, stagger: 0.1 }
  );
  gsap.to("#circlesSmall circle", {
    y: -4,
    yoyo: true,
    duration: 1,
    ease: "sine.inOut",
    repeat: -1
  });
  gsap.to("#circlesBig circle", {
    y: -2,
    yoyo: true,
    duration: 1,
    ease: "sine.inOut",
    repeat: -1
  });

  gsap.set("#glassShine", { x: -68 });

  gsap.to("#glassShine", {
    x: 80,
    duration: 2,
    rotation: -30,
    ease: "expo.inOut",
    transformOrigin: "50% 50%",
    repeat: -1,
    repeatDelay: 8,
    delay: 2
  });

  const burger = document.querySelector('.burger');
  const nav = document.querySelector('nav');

  burger.addEventListener('click',(e) => {
    burger.dataset.state === 'closed' ? burger.dataset.state = "open" : burger.dataset.state = "closed"
    nav.dataset.state === "closed" ? nav.dataset.state = "open" : nav.dataset.state = "closed"
  })
}

$(document).on('click', function (e){
  /* bootstrap collapse js adds "in" class to your collapsible element*/
  var menu_opened = $('.navbar-collapse').hasClass('show');

  if(!$(e.target).closest('.navbar-collapse').length &&
  !$(e.target).is('.navbar-collapse') &&
  menu_opened === true){
  $('.navbar-collapse').collapse('toggle');
  }

  $(".eduSwiper").on('click', function () {
    $(this).addClass('active');
    $(this).siblings(".eduSwiper").removeClass('active');
  });



});








