import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TransportService } from '../transport.service';

@Component({
  selector: 'app-center',
  templateUrl: './center.component.html',
  styleUrls: ['./center.component.scss']
})
export class CenterComponent implements OnInit {

  user: any;
  kumarakom: any;
  above45: any;
  above45D1: any = [];
  above45D2: any = [];
  above18D1: any = [];
  above18D2: any = [];
  message: any;
  back: boolean;

  @ViewChild('myButton') myButton: ElementRef;
  flag1: boolean = true;
  flag2: boolean = true;
  flag3: boolean = true;
  flag4: boolean = true;
  centerId: string;

  triggerClick() {
    let el: HTMLElement = this.myButton.nativeElement as HTMLElement;
    setTimeout(() => el.click(), 1000);
  }
  constructor(private route: ActivatedRoute, private transport: TransportService) {
    setInterval(() => {
      if (this.back)
        this.ngOnInit();
    }
      , 5000);
  }

  ngOnInit(): void {
    this.back = true;
    this.route.paramMap.subscribe(params => {
      this.centerId = params.get('center_id');
    });

    this.transport.getCenter(this.centerId).subscribe((data: any) => {
      console.log(data.centers);
      this.kumarakom = data.centers;
      this.check(this.kumarakom);
    });
  }

  playAudio() {
    let audio = new Audio();
    audio.src = "./../assets/noti.wav";
    audio.load();
    audio.play();

  }

  check(cen) {
    this.kumarakom = cen;
    this.above45D2 = [];
    this.above45D1 = [];
    this.above18D1 = [];
    this.above18D2 = [];


    for (let i = 0; i < this.kumarakom.sessions.length; i++) {
      if (this.kumarakom.sessions[i].available_capacity > 0) {
        if (this.kumarakom.sessions[i].min_age_limit == 45) {
          if (this.kumarakom.sessions[i].available_capacity_dose1 > 0) {
            console.log(this.kumarakom.sessions[i].vaccine, "dose 1 is available for age above 45")
            this.message = '';
            if (this.flag1) {
              this.playAudio();
              this.flag1 = false;
            }
            this.above45D1.push(this.kumarakom.sessions[i].vaccine + " dose 1 is available for age above 45 on " + this.kumarakom.sessions[i].date);
          }
          else if (this.kumarakom.sessions[i].available_capacity_dose2 > 0) {
            console.log(this.kumarakom.sessions[i].vaccine, "dose 2 is available for age above 45")
            this.above45D2.push(this.kumarakom.sessions[i].vaccine + " dose 2 is available for age above 45 on " + this.kumarakom.sessions[i].date);

            this.message = '';
            if (this.flag2) {
              this.playAudio();
              this.flag2 = false;
            }


          }
        }
        else if (this.kumarakom.sessions[i].min_age_limit == 18) {
          if (this.kumarakom.sessions[i].available_capacity_dose1 > 0) {
            console.log(this.kumarakom.sessions[i].vaccine, "dose 1 is available for age above 18")

            this.above18D1.push(this.kumarakom.sessions[i].vaccine + "dose 1 is available for age above 18 on " + this.kumarakom.sessions[i].date);
            this.message = '';
            if (this.flag3) {
              this.playAudio();
              this.flag3 = false;
            }


          }
          else if (this.kumarakom.sessions[i].available_capacity_dose2 > 0) {
            console.log(this.kumarakom.sessions[i].vaccine, " dose 2 is available for age above 18")

            this.above18D2.push(this.kumarakom.sessions[i].vaccine + " dose 2 is available for age above 18 on " + this.kumarakom.sessions[i].date);
            this.message = '';
            if (this.flag4) {
              this.playAudio();
              this.flag4 = false;
            }

          }
        }

      }

    }
    if (this.above18D1 == '' && this.above18D2 == '' && this.above45D1 == '' && this.above45D2 == '') {
      console.log("hey")
      this.message = "No Vaccine Available";
      this.makeTrue();
    }

  }

  makeTrue() {
    this.flag1 = true;
    this.flag2 = true;
    this.flag3 = true;
    this.flag4 = true;
  }

}
