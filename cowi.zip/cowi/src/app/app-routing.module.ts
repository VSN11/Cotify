import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CenterComponent } from './center/center.component';
import { CowinComponent } from './cowin/cowin.component';
import { FavouriteComponent } from './favourite/favourite.component';

const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: '', component: CowinComponent },
  { path: 'center/:center_id', component: CenterComponent },
  { path: 'favouriteCenter', component: FavouriteComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
