import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { formatDate } from '@angular/common';


@Injectable({
  providedIn: 'root'
})
export class TransportService {
  currentDate: Date;
  cValue: string;

  constructor(private http: HttpClient) {
    this.currentDate = new Date();
    this.cValue = formatDate(this.currentDate, 'dd-MM-yyyy', 'en-US');
    console.log(this.cValue)
  }


  getUpdate(id): Observable<any> {
    const url = "https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict?";
    return this.http.get<any>(url + "date=" + this.cValue + "&district_id=" + id).pipe(
      map(data => data)
    );

  }

  getCenter(id) {
    const url = "https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByCenter?";
    return this.http.get(url + "date=" + this.cValue + "&center_id=" + id);

  }

  getDistrict(): Observable<any> {
    const url = "https://cdn-api.co-vin.in/api/v2/admin/location/districts/17";
    return this.http.get<any>(url).pipe(
      map(data => data)
    );

  }
}
