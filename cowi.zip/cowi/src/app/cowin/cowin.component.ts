import { formatDate } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { TransportService } from '../transport.service';


@Component({
  selector: 'app-cowin',
  templateUrl: './cowin.component.html',
  styleUrls: ['./cowin.component.scss']
})

export class CowinComponent implements OnInit {
  user: any;
  kumarakom: any;
  above45: any;
  above45D1: any = [];
  above45D2: any = [];
  above18D1: any = [];
  above18D2: any = [];
  message: any;
  back: boolean;

  @ViewChild('myButton') myButton: ElementRef;
  flag1: boolean = true;
  flag2: boolean = true;
  flag3: boolean = true;
  flag4: boolean = true;
  districts: any;
  selectedDistrict: any;
  applyForm: any;
  register: any;
  favourite: any = [];
  x: any;
  k: any = [];
  name: string;
  show: boolean;
  user1: any;
  active: boolean;
  loading: boolean = false;



  triggerClick() {
    let el: HTMLElement = this.myButton.nativeElement as HTMLElement;
    setTimeout(() => el.click(), 1000);
  }
  constructor(private fb: FormBuilder, private transport: TransportService) {


  }

  ngOnInit(): void {

    this.favourite = localStorage.getItem('favour');
    this.favourite = JSON.parse(this.favourite);

    if (sessionStorage.getItem('centers')) {
      this.user = sessionStorage.getItem('centers');
      this.user = JSON.parse(this.user);
      this.user1 = sessionStorage.getItem('centers');
      this.user1 = JSON.parse(this.user1);

      if (this.favourite != null) {
        for (let i = 0; i < this.user.length; i++) {
          for (let j = 0; j < this.favourite.length; j++) {
            if (this.user[i].center_id == this.favourite[j].center_id) {
              this.user[i] = this.favourite[j];
              console.log(this.user[i]);
            }
          }
        }
      }

    }

    if (sessionStorage.getItem('centers')) {
      this.register = sessionStorage.getItem('district');
      this.register = JSON.parse(this.register);
    }

    this.transport.getDistrict().subscribe((data: any) => {
      this.districts = data.districts;

      console.log(this.districts)
    });
  }

  fav(cen) {
    if (this.favourite == null) {
      this.favourite = [];
      this.favourite.push(cen);
    }
    else {
      this.favourite.push(cen);
    }
    cen.favour = true;
    console.log(this.favourite)
    localStorage.setItem('favour', JSON.stringify(this.favourite));
  }

  favR(cen) {
    cen.favour = false;
    this.x = this.favourite.indexOf(cen);
    this.favourite.splice(this.x, 1)
    console.log(this.favourite);
    localStorage.setItem("favour", JSON.stringify(this.favourite));

  }


  check() {
    this.loading = true;
    console.log(this.register)
    this.transport.getUpdate(this.register.district_id).subscribe((data: any) => {
      this.loading = false
      this.user = data.centers;
      this.user1 = data.centers;
      sessionStorage.setItem("centers", JSON.stringify(this.user));
      sessionStorage.setItem("district", JSON.stringify(this.register));
      console.log(this.user)

      for (let i = 0; i < this.user.length; i++) {
        for (let j = 0; j < this.favourite.length; j++) {
          if (this.user[i].center_id == this.favourite[j].center_id) {
            this.user[i] = this.favourite[j];
            console.log(this.user[i]);
          }
        }
      }


    });
  }


  search() {
    if (this.name == "") {
      this.show = false;
    }
    else {
      this.user = this.user1;
      console.log(this.user);
      this.show = true;
      this.user = this.user.filter((res: { name: string }) => {
        return (res.name.toLocaleLowerCase().match(this.name.toLocaleLowerCase())
        );
      });

      if (this.user == '') {
        this.active = true;
      }
    }

  }



}
