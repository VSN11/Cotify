import { formatDate } from '@angular/common';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { TransportService } from '../transport.service';

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.scss']
})
export class FavouriteComponent implements OnInit, OnDestroy {
  favourite: any = [];
  x: any;
  currentDate: Date;
  cValue: any;
  cValue1: any;
  tomorrow: Date;
  dates: any = [];
  dates1: any = [];
  newDate: any;
  y: string;
  y1: string;
  user: any;
  kumarakom: any = [];
  above45: any;
  above45D1: any = [];
  above45D2: any = [];
  above18D1: any = [];
  above18D2: any = [];
  message: any;
  back: boolean;

  @ViewChild('myButton') myButton: ElementRef;
  flag1: boolean = true;
  flag2: boolean = true;
  flag3: boolean = true;
  flag4: boolean = true;
  centerId: string;

  triggerClick() {
    let el: HTMLElement = this.myButton.nativeElement as HTMLElement;
    setTimeout(() => el.click(), 1000);
  }

  constructor(private transport: TransportService) {
    this.currentDate = new Date();

    this.cValue = formatDate(this.currentDate, 'dd MMM yyyy', 'en-US');
    this.cValue1 = formatDate(this.currentDate, 'dd-MM-yyyy', 'en-US');
    this.dates.push(this.cValue);
    this.dates1.push(this.cValue1);

    for (let i = 1; i < 7; i++) {
      this.newDate = new Date();
      this.tomorrow = new Date(this.newDate.setDate(this.newDate.getDate() + i));
      this.y1 = formatDate(this.tomorrow, 'dd-MM-yyyy', 'en-US');
      this.y = formatDate(this.tomorrow, 'dd MMM yyyy', 'en-US');
      this.dates1.push(this.y1);
      this.dates.push(this.y);



    }

    this.back = true;
    setInterval(() => {

      console.log("loading")
      this.ngOnInit();
    }
      , 10000);

  }

  async ngOnInit() {
    if (this.back) {
      this.kumarakom = [];
      this.user = null;
      this.favourite = localStorage.getItem("favour");
      this.favourite = JSON.parse(this.favourite);

      for (let i = 0; i < this.favourite.length; i++) {
        await this.transport.getCenter(this.favourite[i].center_id).toPromise()
          .then(data => {
            this.user = null;
            this.user = data;
            this.user = this.user.centers;
            console.log(this.user, i)
            this.user.favour = true;
            this.kumarakom.push(this.user);
          });




      }



      setTimeout(() => {
        this.favourite = this.kumarakom;
        console.log(this.favourite)
      }
        , 4000);






    }

  }

  ngOnDestroy() {
    console.log('Items destroyed');
    this.back = false;
  }


  favR(cen) {
    cen.favour = false;
    this.x = this.favourite.indexOf(cen);
    this.favourite.splice(this.x, 1);
    console.log(this.favourite);
    localStorage.setItem("favour", JSON.stringify(this.favourite));
    this.ngOnInit();

  }

  check() {
    for (let k = 0; k < this.kumarakom.length; k++) {
      for (let i = 0; i < this.kumarakom.sessions.length; i++) {
        if (this.kumarakom.sessions[i].available_capacity > 0) {
          if (this.kumarakom.sessions[i].min_age_limit == 45) {
            if (this.kumarakom.sessions[i].available_capacity_dose1 > 0) {
              console.log(this.kumarakom.sessions[i].vaccine, "dose 1 is available for age above 45")
              this.message = '';
              if (this.flag1) {
                this.flag1 = false;
              }
              this.above45D1.push(this.kumarakom.sessions[i].vaccine + " dose 1 is available for age above 45 on " + this.kumarakom.sessions[i].date);
            }
            else if (this.kumarakom.sessions[i].available_capacity_dose2 > 0) {
              console.log(this.kumarakom.sessions[i].vaccine, "dose 2 is available for age above 45")
              this.above45D2.push(this.kumarakom.sessions[i].vaccine + " dose 2 is available for age above 45 on " + this.kumarakom.sessions[i].date);

              this.message = '';
              if (this.flag2) {
                this.flag2 = false;
              }


            }
          }
          else if (this.kumarakom.sessions[i].min_age_limit == 18) {
            if (this.kumarakom.sessions[i].available_capacity_dose1 > 0) {
              console.log(this.kumarakom.sessions[i].vaccine, "dose 1 is available for age above 18")

              this.above18D1.push(this.kumarakom.sessions[i].vaccine + "dose 1 is available for age above 18 on " + this.kumarakom.sessions[i].date);
              this.message = '';
              if (this.flag3) {
                this.flag3 = false;
              }


            }
            else if (this.kumarakom.sessions[i].available_capacity_dose2 > 0) {
              console.log(this.kumarakom.sessions[i].vaccine, " dose 2 is available for age above 18")

              this.above18D2.push(this.kumarakom.sessions[i].vaccine + " dose 2 is available for age above 18 on " + this.kumarakom.sessions[i].date);
              this.message = '';
              if (this.flag4) {
                this.flag4 = false;
              }

            }
          }

        }

      }
    }
    if (this.above18D1 == '' && this.above18D2 == '' && this.above45D1 == '' && this.above45D2 == '') {
      console.log("hey")
      this.message = "No Vaccine Available";
    }

  }

}
